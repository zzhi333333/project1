# -*- coding: utf-8 -*-

import tkinter as tk
from tkinter import filedialog, messagebox
import pandas as pd
from pathlib import Path
from datetime import datetime

# —— 通用：根据字段候选自动选表 —— #
def pick_sheet_by_cols(xls_dict, candidates):
    best_name, best_score, best_df = None, -1, None
    for name, df in xls_dict.items():
        cols = [str(c).strip() for c in df.columns]
        score = sum(1 for cand in candidates if cand.lower() in [c.lower() for c in cols])
        if score > best_score:
            best_name, best_score, best_df = name, score, df
    return best_name, best_df

# —— 识别文件类型（Open PO / PSD） —— #
def detect_role(xlsx_path: Path):
    """
    返回 ('open' or 'psd', 选中的sheet名, 对应DataFrame)
    """
    try:
        xls = pd.read_excel(xlsx_path, sheet_name=None)
    except Exception as e:
        raise RuntimeError(f"读取失败：{xlsx_path}\n{e}")

    # Open PO 典型列
    cands_open = ['ALT Customer PN', 'ALT Compal PN', 'Total', 'DESCRIÇÃO', 'MOT', 'Confirm ETD', 'Model', 'Model type']
    # PSD Report 典型列
    cands_psd  = ['Lenovo PN', 'Material PN', 'Qty', 'Description', 'MOT', 'SCP/PSD Commit', 'Model']

    name_o, df_o = pick_sheet_by_cols(xls, cands_open)
    name_p, df_p = pick_sheet_by_cols(xls, cands_psd)

    score_o = 0 if df_o is None else sum(1 for c in cands_open if c in df_o.columns)
    score_p = 0 if df_p is None else sum(1 for c in cands_psd  if c in df_p.columns)

    if score_o >= score_p and df_o is not None:
        return 'open', name_o, df_o
    elif df_p is not None:
        return 'psd', name_p, df_p
    else:
        raise RuntimeError(f"无法识别文件类型：{xlsx_path}")

# —— 主处理逻辑 —— #
def combine_open_psd(open_df: pd.DataFrame, psd_df: pd.DataFrame) -> pd.DataFrame:
    # 统一去空白
    open_df.columns = [str(c).strip() for c in open_df.columns]
    psd_df.columns  = [str(c).strip() for c in psd_df.columns]

    # Open PO -> 目标列
    # 兼容葡语/中文描述列名
    desc_candidates = ["DESCRIÇÃO", "Descrição", "DESCRICAO", "中文品名",
                       "DESCRIÇÃO ", "DESCRIÇÃO ", "DESCRIÇÃO\xa0"]
    desc_col = next((c for c in desc_candidates if c in open_df.columns), None)
    if desc_col is None:
        # 再宽松一点的兜底（极少见）
        desc_col = next((c for c in open_df.columns if "descr" in c.lower() or "中文" in c), None)

    map_open = {
        "ALT Customer PN": "ALT Customer PN",
        "ALT Compal PN":   "ALT Compal PN",
        "Total":           "Total",
        "MOT":             "MOT",
        "Confirm ETD":     "Confirm ETD",
        "Model":           "Model",
    }
    if desc_col:  # 只有在找到描述列时才加入映射
        map_open[desc_col] = "Description"

    open_sel = open_df[[c for c in map_open if c in open_df.columns]].rename(columns=map_open)

    # PSD Report -> 目标列
    map_psd = {
        "Lenovo PN":       "ALT Customer PN",
        "Material PN":     "ALT Compal PN",
        "Qty":             "Total",
        "Description":     "Description",
        "MOT":             "MOT",
        "SCP/PSD Commit":  "Confirm ETD",
        "Model":           "Model",
    }
    psd_sel = psd_df[[c for c in map_psd if c in psd_df.columns]].rename(columns=map_psd)

    final_cols = ["ALT Customer PN","ALT Compal PN","Total","Description","MOT","Confirm ETD","Model"]
    for d in (open_sel, psd_sel):
        for col in final_cols:
            if col not in d.columns:
                d[col] = pd.NA
        d["Total"] = pd.to_numeric(d["Total"], errors="coerce")
        d["Confirm ETD"] = pd.to_datetime(d["Confirm ETD"], errors="coerce")
        # 丢弃三者全空的行
        d.dropna(how="all", subset=["ALT Customer PN","ALT Compal PN","Total"], inplace=True)

    open_sel = open_sel[final_cols]
    psd_sel  = psd_sel[final_cols]

    # 纵向合并
    combined = pd.concat([open_sel, psd_sel], ignore_index=True)
    # 友好排序
    combined = combined.sort_values(by=["Model","ALT Customer PN","ALT Compal PN"],
                                    kind="stable", na_position="last")
    return combined

def run_gui():
    root = tk.Tk()
    root.withdraw()  # 隐藏主窗体，只用文件对话框

    files = filedialog.askopenfilenames(
        title="请选择两个 Excel 文件（Open PO 与 PSD Report）",
        filetypes=[("Excel files", "*.xlsx;*.xlsm;*.xls")],
    )

    if not files or len(files) != 2:
        messagebox.showwarning("提示", "请一次性选择两个 Excel 文件（按住 Ctrl 或 Shift 多选）")
        return

    path1, path2 = Path(files[0]), Path(files[1])

    # 输出目录：默认使用第一个文件所在目录；若两个不在同一目录，可再做提醒
    if path1.parent != path2.parent:
        if not messagebox.askyesno("提示", "两个文件不在同一目录，将按第一个文件所在目录保存输出。是否继续？"):
            return
    out_dir = path1.parent

    # 自动识别角色
    try:
        role1, sheet1, df1 = detect_role(path1)
        role2, sheet2, df2 = detect_role(path2)
    except Exception as e:
        messagebox.showerror("错误", str(e))
        return

    # 归位：open_df / psd_df
    if role1 == 'open':
        open_df, psd_df = df1, df2
    else:
        open_df, psd_df = df2, df1

    # 合并
    try:
        combined = combine_open_psd(open_df, psd_df)
    except Exception as e:
        messagebox.showerror("错误", f"合并失败：\n{e}")
        return

    # 输出
    mmdd = datetime.now().strftime("%m%d")
    out_path = out_dir / f"LNV Dixon Open PO _ {mmdd}.xlsx"
    try:
        # 用 openpyxl 引擎写出，可保留日期类型
        with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
            combined.to_excel(writer, index=False, sheet_name="Combined")
    except Exception as e:
        messagebox.showerror("错误", f"导出失败：\n{e}")
        return

    messagebox.showinfo("完成", f"已生成：\n{out_path}\n\n行数：{len(combined)}")

if __name__ == "__main__":
    run_gui()
