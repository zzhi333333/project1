import pandas as pd
from utils import select_file_dialog, save_df, SAVE_INTERMEDIATE

def run(sbb_df):
    inv_file = select_file_dialog("请选择 ODM_INVENTORY 文件", "示例: ODM_INVERTORY.xlsx")
    sfg_file = select_file_dialog("请选择 SFG_SBB_Mapping 文件", "示例: SFG_SBB_Mapping.xlsx")

    inv = pd.read_excel(inv_file)
    sfg = pd.read_excel(sfg_file)

    updated = sbb_df.copy()
    updated["订单用量"] = updated["订单用量"].fillna(0) - 0

    if SAVE_INTERMEDIATE:
        save_df(updated, "SBB_订单用量汇总_update.xlsx")
    return updated

if __name__ == "__main__":
    run(pd.DataFrame())
