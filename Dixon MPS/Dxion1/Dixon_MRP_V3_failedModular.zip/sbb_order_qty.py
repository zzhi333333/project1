import pandas as pd
from utils import select_file_dialog, save_df, SAVE_INTERMEDIATE

def run(mapping_df):
    file = select_file_dialog("请选择 MFG PO 文件", "示例: Dixon MFG PO.xlsx")
    dixon_df = pd.read_excel(file)

    pivot_df = dixon_df.groupby("MTM", as_index=False)["Qty"].sum()
    pivot_df.rename(columns={"Qty": "MTM Qty"}, inplace=True)

    pivot_df["MTM"] = pivot_df["MTM"].astype(str).str.strip().str.upper()
    mapping_df["MTM"] = mapping_df["MTM"].astype(str).str.strip().str.upper()

    merged_df = pd.merge(mapping_df, pivot_df, on="MTM", how="left")
    merged_df["订单用量"] = merged_df["Qty"] * merged_df["MTM Qty"]

    final_df = merged_df[["MTM", "SBB", "Qty", "SBB Name", "Basic Name", "MTM Qty", "订单用量"]]

    if SAVE_INTERMEDIATE:
        save_df(final_df, "SBB_订单用量汇总.xlsx")
    return final_df

if __name__ == "__main__":
    run(pd.DataFrame())
