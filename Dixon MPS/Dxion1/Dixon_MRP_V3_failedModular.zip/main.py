import tkinter as tk
from tkinter import filedialog, messagebox
import pandas as pd
from utils import save_df, select_file_dialog, SAVE_INTERMEDIATE
import bom_tool, mtm_mapping, sbb_order_qty, sfg_deduct, mfg_po_bom_mapping, mrp5_1, mrp5_2

def main():
    print("[STEP 1] 运行 BOM Tool")
    bom_data = bom_tool.run()

    print("[STEP 2] 运行 MTM-SBB Mapping")
    mtm_data = mtm_mapping.run()

    print("[STEP 3] 运行 SBB MFG PO Qty Mapping")
    sbb_qty = sbb_order_qty.run(mtm_data)

    print("[STEP 3.1] 运行 SFG 扣减")
    sbb_qty_update = sfg_deduct.run(sbb_qty)

    print("[STEP 4] 运行 MFG PO BOM Mapping")
    mfg_po_bom = mfg_po_bom_mapping.run(bom_data, sbb_qty_update)

    print("[STEP 5.1] 运行 MRP5.1 库存匹配")
    final_mapping = mrp5_1.run(mfg_po_bom)

    print("[STEP 5.2] 运行 MRP5.2 Open PO 合并与净需求计算")
    result = mrp5_2.run(final_mapping)

    if SAVE_INTERMEDIATE:
        save_df(result, "Net_dmd_BPS_result.xlsx")
    print("✅ 全流程完成")

if __name__ == "__main__":
    main()
