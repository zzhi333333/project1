import pandas as pd
from utils import select_file_dialog, save_df, SAVE_INTERMEDIATE

def run(final_mapping):
    po_file = select_file_dialog("请选择 Open PO 文件", "示例: LNV Dixon Open PO.xlsx")
    po = pd.read_excel(po_file)

    merged = final_mapping.copy()
    merged["Net_Demand"] = merged["Final_Demand"].fillna(0) - 0

    if SAVE_INTERMEDIATE:
        save_df(merged, "Net_dmd_BPS_result.xlsx")
    return merged

if __name__ == "__main__":
    run(pd.DataFrame())
