import pandas as pd
from utils import select_file_dialog, save_df, SAVE_INTERMEDIATE

def run():
    file = select_file_dialog("请选择 MTM Mapping 文件", "示例: Multi Product Raw Bill of Materials Export.xlsx")
    df = pd.read_excel(file)
    mapping = df.copy()

    if SAVE_INTERMEDIATE:
        save_df(mapping, "MTM_SBB_mapping.xlsx")
    return mapping

if __name__ == "__main__":
    run()
