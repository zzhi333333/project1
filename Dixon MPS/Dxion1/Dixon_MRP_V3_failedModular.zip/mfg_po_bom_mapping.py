import pandas as pd
from utils import save_df, SAVE_INTERMEDIATE

def run(bom_data, sbb_data):
    leaf = bom_data["leaf"]
    merged = pd.merge(leaf, sbb_data, left_on="SBB", right_on="SBB", how="inner")

    merged["MENGE_times_MFG_PO_Qty"] = merged["MENGE"] * merged["订单用量"] if "MENGE" in merged else 0

    if SAVE_INTERMEDIATE:
        save_df(merged, "MFG_PO_BOM_mapping.xlsx")
    return merged

if __name__ == "__main__":
    run({"leaf": pd.DataFrame()}, pd.DataFrame())
