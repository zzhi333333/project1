import pandas as pd
from utils import select_file_dialog, save_df, SAVE_INTERMEDIATE, ENABLE_MAXFLOW

def run(mfg_po_bom):
    inv_file = select_file_dialog("请选择 ODM_INVENTORY 文件", "示例: ODM_INVERTORY.xlsx")
    inv = pd.read_excel(inv_file)

    merged = mfg_po_bom.copy()
    merged["Final_Demand"] = merged["MENGE_times_MFG_PO_Qty"].fillna(0) - 0

    if ENABLE_MAXFLOW:
        print("运行最大流分配...")

    if SAVE_INTERMEDIATE:
        save_df(merged, "Final_BOM_ODM_Mapping.xlsx")
    return merged

if __name__ == "__main__":
    run(pd.DataFrame())
