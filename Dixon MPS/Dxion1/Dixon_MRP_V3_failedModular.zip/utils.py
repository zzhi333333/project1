import pandas as pd
import tkinter as tk
from tkinter import filedialog

SAVE_INTERMEDIATE = True
ENABLE_MAXFLOW = False

def select_file_dialog(title, example):
    root = tk.Tk()
    root.withdraw()
    print(f"👉 {title} (例如: {example})")
    file = filedialog.askopenfilename(title=title)
    if not file:
        raise FileNotFoundError("未选择文件")
    return file

def save_df(df, filename):
    if df is None or df.empty:
        print(f"⚠️ {filename} 未保存（空 DataFrame）")
        return
    df.to_excel(filename, index=False)
    print(f"✅ 已保存: {filename}")
