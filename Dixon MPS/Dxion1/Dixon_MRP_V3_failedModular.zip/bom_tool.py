import pandas as pd
from utils import select_file_dialog, save_df, SAVE_INTERMEDIATE

def run():
    file = select_file_dialog("请选择 BOM 文件", "示例: DIXON+BOM+all.xlsx")
    df = pd.read_excel(file)

    expanded = df.copy()
    leaf = df.copy()

    if SAVE_INTERMEDIATE:
        save_df(expanded, "DIXON+BOM+all_expanded_bom_tree_sbb_roots.xlsx")
        save_df(leaf, "DIXON+BOM+all_bom_leaf.xlsx")
    return {"expanded": expanded, "leaf": leaf}

if __name__ == "__main__":
    run()
